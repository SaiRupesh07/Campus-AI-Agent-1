#!/usr/bin/env python3
"""
Backend API Testing for Campus AI Agent
"""
import requests
import sys
from datetime import datetime
import json

class CampusAITester:
    def __init__(self, base_url="https://smart-facility-book.preview.emergentagent.com"):
        self.base_url = base_url
        self.session_id = None
        self.tests_run = 0
        self.tests_passed = 0

    def run_test(self, name, method, endpoint, expected_status, data=None):
        """Run a single API test"""
        url = f"{self.base_url}/{endpoint}"
        headers = {'Content-Type': 'application/json'}
        
        self.tests_run += 1
        print(f"\n🔍 Testing {name}...")
        print(f"   URL: {url}")
        
        try:
            if method == 'GET':
                response = requests.get(url, headers=headers, timeout=10)
            elif method == 'POST':
                response = requests.post(url, json=data, headers=headers, timeout=10)

            print(f"   Status: {response.status_code}")
            
            success = response.status_code == expected_status
            if success:
                self.tests_passed += 1
                print(f"✅ PASSED - {name}")
                try:
                    response_data = response.json()
                    if endpoint == "api/events" and isinstance(response_data, list):
                        print(f"   Events found: {len(response_data)}")
                    elif endpoint == "api/facilities" and isinstance(response_data, list):
                        print(f"   Facilities found: {len(response_data)}")
                    elif "chat" in endpoint and isinstance(response_data, dict):
                        print(f"   Response: {response_data.get('response', '')[:100]}...")
                except:
                    pass
            else:
                print(f"❌ FAILED - Expected {expected_status}, got {response.status_code}")
                try:
                    error_text = response.text[:200]
                    print(f"   Error: {error_text}")
                except:
                    pass

            return success, response.json() if success and response.content else {}

        except requests.exceptions.RequestException as e:
            print(f"❌ FAILED - Network Error: {str(e)}")
            return False, {}
        except Exception as e:
            print(f"❌ FAILED - Error: {str(e)}")
            return False, {}

    def test_root_endpoint(self):
        """Test root API endpoint"""
        success, response = self.run_test(
            "Root Endpoint",
            "GET", 
            "api/",
            200
        )
        return success

    def test_events_endpoint(self):
        """Test events API endpoint"""
        success, response = self.run_test(
            "Events Endpoint",
            "GET",
            "api/events", 
            200
        )
        if success and isinstance(response, list):
            print(f"   ✓ Returned {len(response)} events")
            if len(response) > 0:
                event = response[0]
                required_fields = ['id', 'name', 'description', 'date', 'location']
                for field in required_fields:
                    if field in event:
                        print(f"   ✓ Event has {field}: {event[field]}")
                    else:
                        print(f"   ⚠️ Event missing field: {field}")
        return success

    def test_facilities_endpoint(self):
        """Test facilities API endpoint"""
        success, response = self.run_test(
            "Facilities Endpoint",
            "GET",
            "api/facilities",
            200
        )
        if success and isinstance(response, list):
            print(f"   ✓ Returned {len(response)} facilities")
            if len(response) > 0:
                facility = response[0]
                required_fields = ['id', 'name', 'type', 'building', 'capacity']
                for field in required_fields:
                    if field in facility:
                        print(f"   ✓ Facility has {field}: {facility[field]}")
                    else:
                        print(f"   ⚠️ Facility missing field: {field}")
        return success

    def test_bookings_endpoint(self):
        """Test bookings API endpoint"""
        success, response = self.run_test(
            "Bookings Endpoint",
            "GET",
            "api/bookings",
            200
        )
        if success and isinstance(response, list):
            print(f"   ✓ Returned {len(response)} bookings")
        return success

    def test_chat_endpoint(self):
        """Test chat API endpoint"""
        success, response = self.run_test(
            "Chat Endpoint - General Query",
            "POST",
            "api/chat",
            200,
            data={"message": "Hello, can you help me?"}
        )
        if success:
            if 'session_id' in response:
                self.session_id = response['session_id']
                print(f"   ✓ Session ID created: {self.session_id[:8]}...")
            if 'response' in response:
                print(f"   ✓ AI Response: {response['response'][:100]}...")
        return success

    def test_chat_events_query(self):
        """Test chat events query"""
        success, response = self.run_test(
            "Chat Endpoint - Events Query",
            "POST", 
            "api/chat",
            200,
            data={
                "message": "What events are happening?",
                "session_id": self.session_id
            }
        )
        if success:
            if 'intent' in response:
                print(f"   ✓ Intent detected: {response['intent']}")
            if 'data' in response and response['data']:
                print(f"   ✓ Events data returned: {len(response['data'])} events")
        return success

    def test_chat_facilities_query(self):
        """Test chat facilities query"""
        success, response = self.run_test(
            "Chat Endpoint - Facilities Query", 
            "POST",
            "api/chat",
            200,
            data={
                "message": "Show me available facilities",
                "session_id": self.session_id
            }
        )
        if success:
            if 'intent' in response:
                print(f"   ✓ Intent detected: {response['intent']}")
            if 'data' in response and response['data']:
                print(f"   ✓ Facilities data returned: {len(response['data'])} facilities")
        return success

    def test_chat_booking_flow(self):
        """Test chat booking flow"""
        success, response = self.run_test(
            "Chat Endpoint - Booking Request",
            "POST",
            "api/chat", 
            200,
            data={
                "message": "I want to book a room",
                "session_id": self.session_id
            }
        )
        if success:
            if 'intent' in response:
                print(f"   ✓ Intent detected: {response['intent']}")
            if 'response' in response and 'facility' in response['response'].lower():
                print(f"   ✓ Booking flow initiated")
        return success

def main():
    """Main test execution"""
    tester = CampusAITester()
    
    print("🚀 Starting Campus AI Backend Testing")
    print(f"Testing against: {tester.base_url}")
    print("=" * 60)
    
    # Run all tests
    tests = [
        tester.test_root_endpoint,
        tester.test_events_endpoint,  
        tester.test_facilities_endpoint,
        tester.test_bookings_endpoint,
        tester.test_chat_endpoint,
        tester.test_chat_events_query,
        tester.test_chat_facilities_query,
        tester.test_chat_booking_flow,
    ]
    
    for test in tests:
        test()
    
    # Print final results
    print("\n" + "=" * 60)
    print(f"📊 TESTING COMPLETE")
    print(f"Tests Passed: {tester.tests_passed}/{tester.tests_run}")
    success_rate = (tester.tests_passed / tester.tests_run * 100) if tester.tests_run > 0 else 0
    print(f"Success Rate: {success_rate:.1f}%")
    
    if success_rate >= 80:
        print("✅ Backend APIs are working well!")
        return 0
    elif success_rate >= 50:
        print("⚠️ Some backend issues detected")
        return 1
    else:
        print("❌ Significant backend issues found")
        return 2

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)