
Action: file_editor create /app/README.md --file-text "# 🎓 CampusAI - Smart Campus Assistant

<div align=\"center\">

![CampusAI Banner](https://images.unsplash.com/photo-1562774053-701939374585?w=1200&h=400&fit=crop)

**An AI-powered campus management system for students, faculty, and staff**

[![FastAPI](https://img.shields.io/badge/FastAPI-009688?style=for-the-badge&logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com/)
[![React](https://img.shields.io/badge/React-61DAFB?style=for-the-badge&logo=react&logoColor=black)](https://reactjs.org/)
[![MongoDB](https://img.shields.io/badge/MongoDB-47A248?style=for-the-badge&logo=mongodb&logoColor=white)](https://www.mongodb.com/)
[![Tailwind CSS](https://img.shields.io/badge/Tailwind_CSS-38B2AC?style=for-the-badge&logo=tailwind-css&logoColor=white)](https://tailwindcss.com/)
[![GROQ](https://img.shields.io/badge/GROQ-FF6B35?style=for-the-badge&logo=groq&logoColor=white)](https://groq.com/)

[Live Demo](#) · [Report Bug](https://github.com/SaiRupesh07/Campus-AI-Agent-1/issues) · [Request Feature](https://github.com/SaiRupesh07/Campus-AI-Agent-1/issues)

</div>

---

## 📋 Table of Contents

- [About The Project](#-about-the-project)
- [Features](#-features)
- [Tech Stack](#-tech-stack)
- [Getting Started](#-getting-started)
- [API Documentation](#-api-documentation)
- [Project Structure](#-project-structure)
- [Screenshots](#-screenshots)
- [Contributing](#-contributing)
- [License](#-license)
- [Contact](#-contact)

---

## 🎯 About The Project

CampusAI is a comprehensive campus management solution that leverages AI to help students, faculty, and staff navigate campus life. The intelligent chatbot powered by GROQ's Llama-3.3-70b model can answer questions about events, help book facilities, and provide campus information.

### Why CampusAI?

- 🤖 **AI-Powered Assistant** - Natural language conversations for campus queries
- 📅 **Event Discovery** - Browse and register for upcoming campus events
- 🏢 **Facility Booking** - Easy room and lab reservations
- 🌙 **Modern UI** - Beautiful dark/light mode with smooth animations
- 📱 **Responsive Design** - Works seamlessly on desktop and mobile

---

## ✨ Features

### 🗣️ AI Chat Assistant
- Natural language understanding for campus queries
- Multi-turn conversation support with session management
- Intent detection for events, facilities, and bookings
- Guided booking flow through conversation

### 📅 Events Management
- View upcoming campus events with detailed information
- Event cards with images, dates, locations, and tags
- Registration tracking with capacity limits
- Filter events by type (conference, hackathon, lecture, etc.)

### 🏢 Facility Booking
- Browse available facilities (labs, auditoriums, classrooms)
- Real-time availability status
- Modal-based booking with date, time, and purpose
- Booking confirmation and management

### 🎨 Modern UI/UX
- Dark mode primary with light mode toggle
- Collapsible sidebar navigation
- Framer Motion animations throughout
- Mobile-responsive with drawer navigation
- Professional card-based layouts

---

## 🛠️ Tech Stack

### Frontend
| Technology | Purpose |
|------------|---------|
| React 18 | UI Framework |
| Tailwind CSS | Styling |
| Framer Motion | Animations |
| Radix UI | Accessible Components |
| Lucide React | Icons |

### Backend
| Technology | Purpose |
|------------|---------|
| FastAPI | API Framework |
| GROQ API | AI/LLM (Llama-3.3-70b) |
| MongoDB | Database |
| Motor | Async MongoDB Driver |
| Pydantic | Data Validation |

---

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ and Yarn
- Python 3.10+
- MongoDB (local or Atlas)
- GROQ API Key ([Get one free](https://console.groq.com/keys))

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/SaiRupesh07/Campus-AI-Agent-1.git
   cd Campus-AI-Agent-1
   ```

2. **Backend Setup**
   ```bash
   cd backend
   
   # Create virtual environment
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   
   # Install dependencies
   pip install -r requirements.txt
   
   # Create .env file
   cat > .env << EOF
   MONGO_URL=\"mongodb://localhost:27017\"
   DB_NAME=\"campus_ai\"
   GROQ_API_KEY=\"your-groq-api-key-here\"
   EOF
   
   # Run the server
   uvicorn server:app --reload --port 8001
   ```

3. **Frontend Setup**
   ```bash
   cd frontend
   
   # Install dependencies
   yarn install
   
   # Create .env file
   echo \"REACT_APP_BACKEND_URL=http://localhost:8001\" > .env
   
   # Start development server
   yarn start
   ```

4. **Access the Application**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8001/api

---

## 📡 API Documentation

### Base URL
```
http://localhost:8001/api
```

### Endpoints

#### Chat
```http
POST /api/chat
Content-Type: application/json

{
  \"message\": \"What events are happening?\",
  \"session_id\": \"optional-session-id\"
}
```

#### Events
```http
GET /api/events
```
Returns list of upcoming campus events.

#### Facilities
```http
GET /api/facilities
```
Returns list of available facilities for booking.

#### Bookings
```http
GET /api/bookings
```
Returns recent booking history.

---

## 📁 Project Structure

```
Campus-AI-Agent-1/
├── backend/
│   ├── server.py          # FastAPI application
│   ├── tools/             # AI agent tools
│   ├── requirements.txt   # Python dependencies
│   └── .env              # Environment variables
│
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── components/
│   │   │   ├── ui/        # Radix UI components
│   │   │   ├── Sidebar.js
│   │   │   ├── Dashboard.js
│   │   │   ├── Chat.js
│   │   │   ├── Events.js
│   │   │   ├── Facilities.js
│   │   │   └── Settings.js
│   │   ├── context/
│   │   │   └── ThemeContext.js
│   │   ├── lib/
│   │   │   └── utils.js
│   │   ├── App.js
│   │   ├── App.css
│   │   └── index.css
│   ├── package.json
│   └── tailwind.config.js
│
└── README.md
```

---

## 📸 Screenshots

### Dashboard
![Dashboard](https://via.placeholder.com/800x450/1a1a2e/ffffff?text=Dashboard+View)
*Modern dashboard with stats, quick actions, and recent activity*

### AI Chat
![Chat](https://via.placeholder.com/800x450/1a1a2e/ffffff?text=AI+Chat+Interface)
*Conversational AI assistant for campus queries*

### Events
![Events](https://via.placeholder.com/800x450/1a1a2e/ffffff?text=Events+Grid)
*Browse and register for upcoming campus events*

### Facilities
![Facilities](https://via.placeholder.com/800x450/1a1a2e/ffffff?text=Facilities+Booking)
*Book labs, auditoriums, and classrooms*

---

## 🤝 Contributing

Contributions are welcome! Here's how you can help:

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

### Development Guidelines

- Follow the existing code style
- Write meaningful commit messages
- Add tests for new features
- Update documentation as needed

---

## 📄 License

Distributed under the MIT License. See `LICENSE` for more information.

---

## 📧 Contact

**Sai Rupesh** - [@SaiRupesh07](https://github.com/SaiRupesh07)

Project Link: [https://github.com/SaiRupesh07/Campus-AI-Agent-1](https://github.com/SaiRupesh07/Campus-AI-Agent-1)

---

## 🙏 Acknowledgments

- [GROQ](https://groq.com/) - For the blazing fast LLM API
- [Radix UI](https://www.radix-ui.com/) - For accessible component primitives
- [Tailwind CSS](https://tailwindcss.com/) - For utility-first styling
- [Framer Motion](https://www.framer.com/motion/) - For beautiful animations
- [Lucide](https://lucide.dev/) - For the icon set

---

<div align=\"center\">

**⭐ Star this repository if you found it helpful!**

Made with ❤️ by [Sai Rupesh](https://github.com/SaiRupesh07)

</div>
"
Observation: Overwrite successful: /app/README.md
